# Thara's Mehendi Night — Premium E-Invitation

A mobile-first, vertical-scrolling luxury digital invitation built into the existing TanStack Start + React project. Deep burgundy + glowing gold palette, GSAP-driven motion, inline SVG icons only (no emoji).

## Tech adaptation

The project runs on TanStack Start (React + Vite + Tailwind v4). I'll build the invitation as a single route (`/`) rather than raw `index.html`, but follow every visual, motion, and structural spec from your brief. GSAP + ScrollTrigger will be added as dependencies.

## Sections (vertical scroll, in order)

1. **Save The Date hero** — full-screen burgundy floral backdrop, hanging lanterns, gold particles, "Save The Date" + `27 / 06 / 2026`, animated SVG scroll indicator.
2. **Invitation Reveal** — "You Are Invited To" / **Thara's Mehendi Night** (glowing gold script) / "Colours of Love", animated gold divider, side floral slide-ins.
3. **Event Vibe** — floating petals, sparkles, henna ornaments, celebratory line.
4. **Event Details** — 3 glassmorphic burgundy cards with gold borders + inline SVG icons (location pin, calendar, floral dress-code), staggered ScrollTrigger reveal.
5. **Venue Location** — rounded gold-bordered Google Map iframe (Manjal Restaurant & Hotels, Colombo 13) + "Open Location" button → opens Google Maps in new tab.
6. **Closing & RSVP** — lanterns + floral framing, three actions: RSVP Now, Confirm on WhatsApp, Add to Calendar.

Floating music toggle (bottom-right, inline SVG speaker icons) overlays all sections; gracefully hides if audio missing.

## Interactions

- **RSVP popup** — GSAP-animated bottom sheet (overlay fade + sheet slide-up). Fields: Name, Attending/Not Attending toggle, guest count, message. Submit composes a WhatsApp message from the inputs and opens `wa.me/REPLACE_WITH_WHATSAPP_NUMBER`.
- **WhatsApp button** — direct link to `wa.me/REPLACE_WITH_WHATSAPP_NUMBER` with the prefilled RSVP confirmation text from your brief.
- **Add to Calendar popup** — three options:
  - Google Calendar → `calendar.google.com/calendar/render?action=TEMPLATE&...` link.
  - Apple Calendar → downloads generated `.ics` blob.
  - Outlook → downloads the same `.ics`.
  - Event: `Thara's Mehendi Night`, 2026-06-27 17:30 → 22:30 Asia/Colombo, Manjal Restaurant & Hotels Colombo 13, full description.
- **Music toggle** — references `/assets/music/mehendi-theme.mp3` (placeholder path under `public/`); button hides if the file fails to load.

## Design system

- CSS variables in `src/styles.css` (oklch tokens): `--burgundy`, `--plum`, `--wine`, `--rose`, `--amber`, `--gold`, `--gold-glow`, plus shadow/border/radius tokens.
- Fonts via Google Fonts `<link>` in `__root.tsx` head: **Great Vibes** (hero script), **Cormorant Garamond** (serif titles), **Poppins** (body).
- Reusable component primitives: `Section`, `LuxuryCard`, `GoldDivider`, `GoldButton`, `Lantern`, `Petal`, `FloralCorner`, `IconSvg` (sprite of all inline SVGs).
- All icons hand-authored inline SVG (location pin, calendar, floral motif, navigation arrow, speaker on/off, close X, Google/Apple/Outlook calendar marks, WhatsApp glyph drawn as line icon).

## Motion (GSAP + ScrollTrigger)

- Hero timeline on mount: background fade → lantern glow pulse loop → title fade+scale → date slide-up → scroll indicator bob loop.
- ScrollTrigger reveals per section (fade + 24px rise), card stagger 0.96→1 scale, gold divider scaleX from center, side florals slide from ±40px.
- Continuous: petal float, particle drift, lantern sway, subtle parallax on floral layers.
- Popups: overlay fade 0→1, sheet y:100%→0 with eased stagger on inner buttons.
- Respects `prefers-reduced-motion` (disables loops + ScrollTriggers, keeps static layout).

## Imagery

Generated via premium image gen and stored under `src/assets/`:
- Hero burgundy floral backdrop (1536×1920 portrait).
- Lantern PNG with transparent background.
- Floral corner ornament (transparent PNG, mirrored via CSS).
- Henna-pattern divider asset (transparent PNG).
- Petal sprite (transparent PNG, reused for floating layer).

## File plan

- `src/routes/index.tsx` — composes the page from section components.
- `src/components/invite/` — `Hero.tsx`, `Reveal.tsx`, `Vibe.tsx`, `Details.tsx`, `Venue.tsx`, `Closing.tsx`, `RsvpSheet.tsx`, `CalendarSheet.tsx`, `MusicToggle.tsx`, `Decor.tsx` (lanterns/petals/particles), `Icons.tsx`.
- `src/lib/calendar.ts` — `.ics` builder + Google Calendar URL helper.
- `src/styles.css` — palette, gold gradient, glow shadows, font imports, base body bg.
- `src/routes/__root.tsx` — add Google Fonts links + updated meta (title "Thara's Mehendi Night", description, og tags).
- `public/assets/music/` — directory placeholder (mp3 to be added by you).
- `package.json` — add `gsap`.

## Placeholders you'll need to swap

- `REPLACE_WITH_WHATSAPP_NUMBER` — used in both WhatsApp button and RSVP submit handler.
- `public/assets/music/mehendi-theme.mp3` — drop the track here when ready; the music toggle auto-hides until it loads.

After your approval I'll implement everything in one pass and verify the build.
